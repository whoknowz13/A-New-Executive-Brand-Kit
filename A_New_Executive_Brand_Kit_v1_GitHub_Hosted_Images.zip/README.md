# A.New Executive Brand Kit v1.0 - GitHub Hosted Images

This version is intended for Modern Retail CRM.

The images use public GitHub raw URLs:
- https://raw.githubusercontent.com/whoknowz13/A-New-Executive-Brand-Kit/main/signature/assets/austin-headshot.jpg
- https://raw.githubusercontent.com/whoknowz13/A-New-Executive-Brand-Kit/main/signature/assets/a-new-signature.png

Make sure the image files are uploaded to your GitHub repo at those exact paths.
