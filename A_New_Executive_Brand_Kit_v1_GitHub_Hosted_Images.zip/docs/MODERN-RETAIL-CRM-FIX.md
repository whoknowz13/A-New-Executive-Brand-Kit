# Modern Retail CRM Image Fix

Modern Retail CRM is likely blocking local images and base64 embedded images.

Use the GitHub-hosted version instead:

1. Open your GitHub repo:
   https://github.com/whoknowz13/A-New-Executive-Brand-Kit

2. Upload these files from this package into this exact folder path:
   signature/assets/austin-headshot.jpg
   signature/assets/a-new-signature.png

3. Upload this file into:
   signature/AustinNew.vcf

4. Then open:
   signature/AustinNewSignature-GitHubHostedImages.html

5. Copy the rendered signature and paste it into Modern Retail CRM.

This version uses public HTTPS image URLs, which most CRMs allow.
